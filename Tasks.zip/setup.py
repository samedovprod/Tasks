# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['tasks']
setup_kwargs = {
    'name': 'tasks',
    'version': '0.0.3',
    'description': 'Задачи',
    'long_description': 'Задачи',
    'author': 'Nazar2k4',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
