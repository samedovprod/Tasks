import tasks
while True:
        print("1. Найти минимальное значение")
        print("2. Меню каферд")
        print("0. выйти из программы")
        cmd = input("Выберите пункт: ")
        
        if cmd == "1":
            tasks.minValue()
        elif cmd == "2":
            tasks.menu()
        elif cmd == "0":
            break
        else:
            print("Вы ввели не правильное значение")
