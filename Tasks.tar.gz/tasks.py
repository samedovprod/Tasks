#Сделал всё что по силам
def minValue():
    a = int(input("Введите переменную a:"))
    b = int(input("Введите переменную b:"))
    c = int(input("Введите переменную c:"))

    if a<b<c:
        print("Минимально значение a: ", a)
    elif b<a<c:
        print("Минимально значение b: ", b)
    elif c<a<b:
        print("Минимально значение c: ", c)
    else:
        print("Неизвестная ошибка")

def menu():
     while True:
        print("1. Кафедра ТК:")
        print("2. Факультет ФИСТ")
        print("3. Каферда Радиотехника")
        print("0. Выйти")
        cmd = input("Выберите пункт: ")

        if cmd == "1":
            print("Выбран 1 пункт")
        elif cmd == "2":
            print("Выбран 3 пункт")
        elif cmd == "3":
            print("Выбран 3 пункт")
        elif cmd == "0":
            break
        else:
            print("Вы ввели не правильное значение")
